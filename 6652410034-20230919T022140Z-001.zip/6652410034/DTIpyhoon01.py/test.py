def showLO() :
    print('hi..')
    print('สวัสดี..')

showLO()
print('hey....')
showLO()