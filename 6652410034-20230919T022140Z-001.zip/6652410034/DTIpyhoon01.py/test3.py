teccc = float(input('ราคาต้นทุน'))
oo = teccc + (teccc*10/100)
print('ราคา',  oo  ,'บาท')
