if 7 < 20 ** 2 :
    print('hi   ')
    print('hey')
    print('------------')
else :
    print('SAU----------')
    print('SAU----------')

print('SAU----------')
