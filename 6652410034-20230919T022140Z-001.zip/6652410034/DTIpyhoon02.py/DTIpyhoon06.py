# for

for x in range(5):
    print(f'DTI-{x}')

print('..................')

for y in range(2,5):
    print(f'SAU-{y}')

print('..................')

for z in range(2,5,3):
    print(f'DTI1-{z}')

for a in range(3,30,5):
    print(f'D1-{a}')

print('hello..')