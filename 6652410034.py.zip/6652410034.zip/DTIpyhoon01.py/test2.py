def funcA(x,y) :
    print(f'x is {x}')
    print(f'y is {y}')
    print(f'Sun {x}+{y}={x+y}')

funcA(10,20)    
funcA(1,4)
funcA(5,5)    