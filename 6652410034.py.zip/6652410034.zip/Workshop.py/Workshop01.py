def inputProductname() :
    LEM = str(input('ซื่อสินค้า'))
    return LEM
def inputproduct() :
    Mrpo = int(input('ราค้าสินค้า'))
    DIO_arora = Mrpo + (Mrpo*10/100)
    print('ราคาขาย',DIO_arora,'สินค้า')


print('<<<<<<<<<<<<<<>>>>>>>>>>>>>>')
print('        Productname         ')
print('<<<<<<<<<<<<<<>>>>>>>>>>>>>>')
LEM = inputProductname()
print('----------------------------')
print("     Check_the_product      ")
print('----------------------------')
DIO_arora = inputproduct()