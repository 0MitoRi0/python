fo_gg = str(input('ID'))
fa_h = str(input('Pess'))
Mr_p = int(input('เงินเดือนปกติ'))
TH = Mr_p - (Mr_p*7/100)-500
print(f'ID{fo_gg} Pess {fa_h}เงินเดือนปกติ{TH}')