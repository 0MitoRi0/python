# while

x=1

while x<=5:
    print('DTI')
    x=x+1

print('hi.........')
